// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include <module/module.h>

#include <cpu/functions.h>
#include <kernel/state.h>
#include <kernel/types.h>

#include <cstring>

EXPORT(int, ksceKernelCpuAtomicAddAndGet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAddAndGet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAddAndGet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAddAndGet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAddUnless16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAddUnless32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAddUnless64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAddUnless8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAndAndGet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAndAndGet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAndAndGet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicAndAndGet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearAndGet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearAndGet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearAndGet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearAndGet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearMask16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearMask32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearMask64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicClearMask8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicCompareAndSet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicCompareAndSet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicCompareAndSet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicCompareAndSet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicDecIfPositive16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicDecIfPositive32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicDecIfPositive64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicDecIfPositive8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAdd16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAdd32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAdd64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAdd8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAnd16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAnd32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAnd64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndAnd8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndClear16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndClear32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndClear64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndClear8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndOr16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndOr32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndOr64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndOr8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSub16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSub32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSub64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndSub8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndXor16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndXor32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndXor64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicGetAndXor8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicOrAndGet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicOrAndGet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicOrAndGet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicOrAndGet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSetIfGreaterGet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSetIfGreaterGet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSetIfGreaterGet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSubAndGet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSubAndGet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSubAndGet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicSubAndGet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicXorAndGet16) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicXorAndGet32) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicXorAndGet64) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuAtomicXorAndGet8) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuDcacheAndL2CleanInvalidateMVACRange_20) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuDcacheAndL2InvalidateRange) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuDcacheAndL2WritebackInvalidateRange) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuDcacheAndL2WritebackRange) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuDcacheInvalidateRange) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuDcacheWritebackRange) {
    return UNIMPLEMENTED();
}

// Cache ops used by kubridge (3.60 SceSysmemForDriver NIDs)
EXPORT(int, ksceKernelCpuDcacheWritebackInvalidateRange) {
    // No-op in emulator — no real CPU cache
    return 0;
}

EXPORT(int, ksceKernelCpuIcacheInvalidateRange, Address addr, uint32_t size) {
    emuenv.kernel.invalidate_jit_cache(addr, size);
    return 0;
}

EXPORT(int, ksceKernelCpuIcacheAndL2WritebackInvalidateRange, Address addr, uint32_t size) {
    emuenv.kernel.invalidate_jit_cache(addr, size);
    return 0;
}

EXPORT(int, ksceKernelCpuUnrestrictedMemcpy, Ptr<void> dst, Ptr<const void> src, uint32_t len) {
    if (!dst || !src)
        return SCE_KERNEL_ERROR_ILLEGAL_ADDR;
    std::memcpy(dst.get(emuenv.mem), src.get(emuenv.mem), len);
    return 0;
}

EXPORT(int, ksceKernelCpuDisableInterrupts) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuEnableInterrupts) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuGetCpuId) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuIsVaddrMapped) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuLockStoreFlag) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuLockStoreLR) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuLockSuspendIntrStoreFlag) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuResumeIntr) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuSpinLockIrqRestore) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuSpinLockIrqSave) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuSpinLockStoreLR) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuSpinUnlockStoreLR) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuSuspendIntr) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuTryLockStoreFlag) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuTryLockStoreLR) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuTryLockSuspendIntrStoreFlag) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuTryLockSuspendIntrStoreLR) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuTrySpinLockStoreLR) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuTrySpinLockSuspendIntrStoreLR) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuUnlockResumeIntrStoreFlag) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuUnlockStoreFlag) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelCpuUnlockStoreLR) {
    return UNIMPLEMENTED();
}

// SceExcpmgrForKernel stubs (kubridge-required)
EXPORT(int, sceKernelRegisterExceptionHandler, int excpKind, int prio, Ptr<void> handler) {
    LOG_WARN("sceKernelRegisterExceptionHandler: excpKind={} prio={} (no-op in emulator)", excpKind, prio);
    return 0;
}

EXPORT(int, sceKernelReturnFromException, Ptr<void> context) {
    LOG_WARN("sceKernelReturnFromException: no-op in emulator");
    return 0;
}
