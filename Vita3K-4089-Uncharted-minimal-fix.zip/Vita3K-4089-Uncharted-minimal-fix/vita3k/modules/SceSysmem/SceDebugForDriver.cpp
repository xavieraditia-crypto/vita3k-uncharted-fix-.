// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include "../SceLibKernel/SceLibKernel.h"
#include <module/module.h>
#include <util/tracy.h>

TRACY_MODULE_NAME(SceDebugForDriver)

EXPORT(int, ksceDebugPrintKernelAssertion) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceDebugPrintKernelPanic) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceDebugPrintf, const char *fmt, module::vargs args) {
    TRACY_FUNC(ksceDebugPrintf, fmt);
    return CALL_EXPORT(sceClibPrintf, fmt, args);
}

EXPORT(int, ksceDebugPrintf2) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceDebugPrintfKernelAssertion) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceDebugPrintfKernelPanic) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceEventLogGetInfo) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelGetMinimumAssertionLevel) {
    return UNIMPLEMENTED();
}

EXPORT(int, ksceKernelGetTtyInfo) {
    return UNIMPLEMENTED();
}
