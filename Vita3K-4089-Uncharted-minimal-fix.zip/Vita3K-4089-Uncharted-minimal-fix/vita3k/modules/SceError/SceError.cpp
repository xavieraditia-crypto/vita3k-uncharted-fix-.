// Vita3K emulator project
// Copyright (C) 2026 Vita3K team
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

#include "SceError.h"

TRACY_MODULE_NAME(SceError);

EXPORT(SceInt32, _sceErrorGetExternalString, char *result, uint32_t err) {
    TRACY_FUNC(_sceErrorGetExternalString, result, err);
    sprintf(result, "0x%08X", err);
    return 0;
}

EXPORT(int, _sceErrorHistoryClearError) {
    return UNIMPLEMENTED();
}

EXPORT(int, _sceErrorHistoryGetError) {
    return UNIMPLEMENTED();
}

EXPORT(int, _sceErrorHistoryPostError) {
    return UNIMPLEMENTED();
}

EXPORT(int, _sceErrorHistorySetDefaultFormat) {
    return UNIMPLEMENTED();
}

EXPORT(int, _sceErrorHistoryUpdateSequenceInfo) {
    return UNIMPLEMENTED();
}
